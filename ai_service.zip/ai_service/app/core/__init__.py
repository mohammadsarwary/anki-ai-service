# Core configuration and shared infrastructure package
